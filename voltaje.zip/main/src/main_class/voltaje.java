package main_class;

import java.util.Scanner;

public class voltaje {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		Scanner tc=  new Scanner(System.in);
		
		int n;
		double voltaje = 0, suma=0;
		
		System.out.println("ingrese la cantidad de voltajes");
		n= tc.nextInt();
		
		for (int i = 0; i < n; i++) {
            System.out.print("Ingrese el voltaje " + (i + 1) + ": ");
            voltaje = tc.nextDouble();
            suma += voltaje;
		}
		double max = voltaje;
        double min = voltaje;
        
        for (int i = 1; i < n; i++) {
            if (voltaje > max) {
                max = voltaje;
            }
            if (voltaje < min) {
                min = voltaje;
            }
            double promedio = suma / n;

            System.out.println("El voltaje máximo es: " + max);
            System.out.println("El voltaje mínimo es: " + min);
            System.out.println("El promedio de los voltajes es: " + promedio);

	}
	}
}

